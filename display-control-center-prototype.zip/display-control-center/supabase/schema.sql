-- Display Control Center: initial single-admin schema, ready for multiple customers.
-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  device_code text not null unique,
  name text not null,
  token_hash text not null,
  created_at timestamptz not null default now(),
  last_seen timestamptz
);

create table if not exists public.commands (
  id bigint generated always as identity primary key,
  device_id uuid not null references public.devices(id) on delete cascade,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  payload jsonb not null,
  status text not null default 'queued' check (status in ('queued','delivered','failed')),
  created_at timestamptz not null default now(),
  delivered_at timestamptz
);

create index if not exists commands_device_status_idx on public.commands(device_id,status,id);

alter table public.devices enable row level security;
alter table public.commands enable row level security;

create policy "users read own devices" on public.devices for select to authenticated using (owner_id = auth.uid());
create policy "users add own devices" on public.devices for insert to authenticated with check (owner_id = auth.uid());
create policy "users update own devices" on public.devices for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "users delete own devices" on public.devices for delete to authenticated using (owner_id = auth.uid());

create policy "users read own commands" on public.commands for select to authenticated using (owner_id = auth.uid());
create policy "users queue commands for own devices" on public.commands for insert to authenticated with check (
  owner_id = auth.uid() and exists (select 1 from public.devices d where d.id = device_id and d.owner_id = auth.uid())
);

-- Device-side RPC. A device proves possession of its per-device token.
-- It returns one queued command and marks it delivered. The token is never stored in plaintext.
create or replace function public.device_next_command(p_device_code text, p_device_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_device public.devices%rowtype;
  v_command public.commands%rowtype;
begin
  select * into v_device from public.devices
  where device_code = p_device_code
    and token_hash = encode(digest(p_device_token, 'sha256'), 'hex');
  if not found then
    return jsonb_build_object('error','unauthorized');
  end if;

  update public.devices set last_seen = now() where id = v_device.id;

  select * into v_command from public.commands
  where device_id = v_device.id and status = 'queued'
  order by id asc limit 1 for update skip locked;

  if not found then return null; end if;

  update public.commands set status='delivered', delivered_at=now() where id=v_command.id;
  return jsonb_build_object('id',v_command.id,'payload',v_command.payload);
end;
$$;

revoke all on function public.device_next_command(text,text) from public;
grant execute on function public.device_next_command(text,text) to anon, authenticated;

-- Prevent browser users from reading the token hash through the normal devices API.
-- The dashboard selects only safe columns; RLS controls row ownership.
