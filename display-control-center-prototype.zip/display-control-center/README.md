# Display Control Center — prototype 0.1

This is the first hosted-software scaffold for the existing ESP32-2432S028 (CYD) eBay display project.

## What this starter includes

- Browser dashboard with Supabase email-link sign-in.
- Device registration with a unique device code and one-time device token.
- Per-user device and command tables with Row Level Security.
- A device-side RPC (`device_next_command`) that authenticates a device token, updates its last-seen time, and returns one queued command.
- UI command types for eBay item ID, refresh, brightness, and future generic price/text mode.

## Important: what is not connected yet

The uploaded Arduino sketch currently runs a local `WebServer` on port 80 and talks directly to eBay from the ESP32. It does not yet call Supabase or poll a cloud command queue. The dashboard can queue commands, but they will not reach the board until the firmware polling and command-handler patch is installed.

The generic `set_price` and `set_text` command types also require a new generic display mode in the firmware; the current sketch's display data model is eBay-specific (`itemTitle`, `itemPrice`, `itemBids`, `itemEnd`, `isAuction`).

## 1. Create the Supabase project

1. Create a free project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy the Project URL and publishable/anon key.
4. In Authentication → URL Configuration, set your deployed website URL as the Site URL. Add it to Redirect URLs too.
5. In Authentication → Providers, enable Email (magic link).

Do not use the `service_role` key in the website or ESP32 firmware. The dashboard only needs the publishable/anon key.

## 2. Deploy the website free

The `web` folder is a static site suitable for Cloudflare Pages.

1. Create a GitHub repository and upload `web/index.html` as the repository's `index.html` (or set the Pages build output directory to `web`).
2. In Cloudflare Pages, create a project connected to that repository.
3. Use no build command; set the output directory to `web`.
4. Open the generated `*.pages.dev` URL.
5. Enter the Supabase Project URL and publishable/anon key in the setup panel, then sign in.

The Supabase URL and publishable/anon key are public client configuration, not secrets. Never put eBay client secrets, Supabase service-role keys, or device tokens in the website source.

## 3. Register a test device

1. Sign into the dashboard.
2. Click Add display.
3. Save the device code and token shown in the one-time popup. The token is not recoverable from the dashboard after creation; if lost, delete/recreate the device or add a token-rotation feature.
4. Do not expect the board to receive commands yet. Firmware integration is the next development step.

## 4. Firmware integration plan

The existing sketch should retain its local web server and all current display behavior. Add a cloud client that:

- polls `POST https://YOUR_PROJECT.supabase.co/rest/v1/rpc/device_next_command` every 5–10 seconds;
- sends `apikey: YOUR_PUBLISHABLE_KEY`, `Authorization: Bearer YOUR_PUBLISHABLE_KEY`, and JSON `{ "p_device_code": "...", "p_device_token": "..." }`;
- validates the TLS certificate (do not use `setInsecure()` in a commercial device);
- parses returned JSON and dispatches `set_item_id`, `refresh`, and `set_brightness` to existing functions;
- adds a separate generic mode and renderer before enabling `set_price` and `set_text`.

The current sketch uses ArduinoJson 7-style `JsonDocument`, `WebServer`, `Preferences`, LovyanGFX, and XPT2046. The integration patch must be merged into that exact project and compiled against the installed board package/library versions.

## 5. Security work before real customers

- Rotate the Wi-Fi password and eBay application secret that were embedded in the uploaded source.
- Remove secrets from firmware source and use a secure provisioning flow.
- Replace `WiFiClientSecure::setInsecure()` with certificate validation for eBay and cloud requests.
- Add device-token rotation, rate limiting, command expiry, and delivery acknowledgements.
- Keep each customer's devices isolated by `owner_id` and test RLS with separate accounts.

## Current command payload shapes

```json
{ "type": "set_item_id", "item_id": "377625672496" }
{ "type": "refresh" }
{ "type": "set_brightness", "value": 128 }
{ "type": "set_price", "value": "149.99" }
{ "type": "set_text", "value": "SPECIAL OFFER" }
```

The first three can map to existing sketch behavior. The last two need generic-mode firmware work.
